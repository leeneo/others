package com.bilibili.model.event;

/**
 * Created by miserydx on 17/12/19.
 */

public class ToggleDrawerEvent {
}
