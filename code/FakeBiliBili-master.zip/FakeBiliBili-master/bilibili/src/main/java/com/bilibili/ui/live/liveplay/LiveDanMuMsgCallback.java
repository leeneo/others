package com.bilibili.ui.live.liveplay;

/**
 * Created by miserydx on 17/9/11.
 */

public abstract class LiveDanMuMsgCallback extends LiveDanMuCallback {

}
