package com.bilibili.widget.danmu.live;

/**
 * Created by czp on 17-6-24.
 */
class ScriptEntity {
    Integer roomId;
    Long random;
    Integer roomURL;
}
