package com.bilibili.widget.danmu.live.entity;

/**
 * Created by czp on 17-5-24.
 */
public class SysGiftEntity extends JSONEntity {
    public String msg;
    public Long rnd;
    public Integer uid;
}
