package com.bilibili.model.event;

/**
 * Created by miserydx on 18/3/10.
 */

public class LivePartialRefreshEvent {
}
