package com.bilibili.widget.danmu.live.entity;

/**
 * The parent of all JSON data package entity.
 * Created by czp on 17-5-25.
 */
public class JSONEntity {
    /**
     * Type of data.
     */
    public String cmd;
}
