package com.bilibili.widget.danmu.live.entity;

/**
 * Created by czp on 17-6-1.
 */
public class RoomAdminsEntity extends JSONEntity {
    public Integer[] uids;
    public Integer roomid;
}
