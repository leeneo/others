package com.bilibili.widget.danmu.live.entity;

/**
 * Created by czp on 17-5-24.
 */
public class PreparingEntity extends JSONEntity {
    public Integer roomid;
}
