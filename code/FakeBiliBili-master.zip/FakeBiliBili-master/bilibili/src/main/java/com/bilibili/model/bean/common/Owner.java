package com.bilibili.model.bean.common;

/**
 * Created by miserydx on 18/3/3.
 */

public class Owner {
    private String face;

    private int mid;

    private String name;

    public void setFace(String face) {
        this.face = face;
    }

    public String getFace() {
        return this.face;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public int getMid() {
        return this.mid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

}
