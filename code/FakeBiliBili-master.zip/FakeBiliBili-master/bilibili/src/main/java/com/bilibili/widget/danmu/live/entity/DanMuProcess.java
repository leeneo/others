package com.bilibili.widget.danmu.live.entity;

/**
 * Created by miserydx on 17/9/11.
 */

public interface DanMuProcess<T> {

    void process(T t);

}
