package com.bilibili.widget.danmu.live.entity;

/**
 * Created by czp on 17-5-24.
 */
public class SysMSGEntity extends JSONEntity {
    public String msg;
    public Integer rep;
    public String url;
}
