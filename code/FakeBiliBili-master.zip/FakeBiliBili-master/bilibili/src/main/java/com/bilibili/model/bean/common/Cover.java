package com.bilibili.model.bean.common;

/**
 * Created by miserydx on 18/3/3.
 */

public class Cover {
    private String src;

    private int height;

    private int width;

    public void setSrc(String src) {
        this.src = src;
    }

    public String getSrc() {
        return this.src;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getHeight() {
        return this.height;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getWidth() {
        return this.width;
    }

}
