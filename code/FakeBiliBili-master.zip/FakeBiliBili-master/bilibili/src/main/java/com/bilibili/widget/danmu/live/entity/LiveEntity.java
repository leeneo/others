package com.bilibili.widget.danmu.live.entity;

/**
 * Created by czp on 17-5-24.
 */
public class LiveEntity extends JSONEntity {
    public Integer roomid;
}
