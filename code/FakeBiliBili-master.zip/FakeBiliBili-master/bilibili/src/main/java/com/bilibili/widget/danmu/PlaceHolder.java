package com.bilibili.widget.danmu;

/**
 * Created by miserydx on 17/9/11.
 */

public class PlaceHolder {
}
