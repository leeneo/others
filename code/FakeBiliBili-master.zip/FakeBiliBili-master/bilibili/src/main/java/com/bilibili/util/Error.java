package com.bilibili.util;

/**
 * Created by miserydx on 18/3/2.
 */

public interface Error {

    void accept();

}
