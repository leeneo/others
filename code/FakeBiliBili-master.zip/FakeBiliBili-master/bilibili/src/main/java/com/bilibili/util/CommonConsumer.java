package com.bilibili.util;

import io.reactivex.functions.Consumer;

/**
 * Created by miserydx on 17/10/24.
 */

public interface CommonConsumer extends Consumer<Object> {
}
