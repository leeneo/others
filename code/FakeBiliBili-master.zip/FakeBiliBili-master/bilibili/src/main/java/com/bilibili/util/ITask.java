package com.bilibili.util;

/**
 * Created by miserydx on 18/3/2.
 */

public interface ITask {

    void execute() throws Exception;;

}
