package com.bilibili.di.module;

import dagger.Module;

/**
 * Created by jiayiyang on 17/4/14.
 */

@Module
public class FragmentModule {
}
