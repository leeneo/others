package com.bilibili.model.bean.common;

/**
 * Created by miserydx on 18/3/3.
 */

public class Entrance_icon {
    private String src;

    private String height;

    private String width;

    public void setSrc(String src) {
        this.src = src;
    }

    public String getSrc() {
        return this.src;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getHeight() {
        return this.height;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getWidth() {
        return this.width;
    }

}
