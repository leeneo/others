package com.team.ijkplayer.player;

/**
 * Created by miserydx on 17/9/25.
 */

public interface IRenderView {
}
