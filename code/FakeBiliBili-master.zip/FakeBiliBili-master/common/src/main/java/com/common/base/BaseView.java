package com.common.base;

/**
 * Created by jiayiyang on 17/3/23.
 */

public interface BaseView {

}
