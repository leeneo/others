package com.common.widget.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by miserydx on 18/1/19.
 */

public abstract class BaseViewHolder extends RecyclerView.ViewHolder {

    public BaseViewHolder(View itemView) {
        super(itemView);
    }
}
