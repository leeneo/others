package com.common.base;

/**
 * Created by jiayiyang on 17/3/23.
 */

public interface BasePresenter {

    void loadData();

    void releaseData();
}
