package com.common.widget.adapter;

/**
 * Created by miserydx on 17/11/20.
 */

public abstract class BaseLoadFailedBinder<VH extends BaseViewHolder> extends LoadViewBinder<VH> {

}
