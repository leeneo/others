package com.common.widget.adapter;

/**
 * Created by miserydx on 17/12/24.
 */

public abstract class BaseLoadingBinder<VH extends BaseViewHolder> extends LoadViewBinder<VH> {

}
