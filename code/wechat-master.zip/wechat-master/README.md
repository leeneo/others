# wechat
WeChat/weixin/微信 app using WebAPI 2 &amp; HttpClient.
