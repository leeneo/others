# UowMVC

A simple, lightweight ASP.net MVC framework base on Unit of work pattern. 

一个简单的、轻量级、兼容移动端的基于Unit of work工作单元模式的ASP.net MVC快速开发框架。

Demo: http://uowmvc.com  admin 123456

Admin Theme: http://uowmvc.com/npts_10_cvl.zip

Wiki: https://github.com/night-king/UowMVC/wiki


欢迎使用本系统

版权所有：袁圈 (http://www.deepleo.com/)

项目代码：https://github.com/night-king/UowMVC

友情提示

1.没有看到左侧菜单，请点击下方“初始化菜单”按钮。

2.项目发布后请删除下方“初始化菜单”按钮。

3.欢迎加入讨论组：279717371（敲门砖：UowMVC）

4.基于此项目开发了灵活轻量级的CMS系统：UowMVC-CMS，欢迎订阅：https://github.com/night-king/UowMVC-CMS

5.基于UowMVC + WeixinSDK (https://github.com/night-king/weixinSDK) 
  
  计划开发微信公众号管理系统：UowMVC-Weixin ( https://github.com/night-king/UowMVC-Weixin ) ，Star过 1000，正式启动，O(∩_∩)O。
